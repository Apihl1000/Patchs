<?php

$config['disable_visitor_graph'] = 0;