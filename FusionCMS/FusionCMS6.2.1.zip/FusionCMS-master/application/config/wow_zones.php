<?php 

$config['zones'] = lang("zones", "wow_zones");